<template>
    <div class="footer" style="color:white">
        Footer
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped></style>