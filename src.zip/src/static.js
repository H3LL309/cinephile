export const apiKey = 'd492c42dceccabf540591cdefbcdbd2f'
export const imgUrlFull = 'https://image.tmdb.org/t/p/original/'
export const imgUrl = 'https://image.tmdb.org/t/p/w500/'


